import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newbooks',
  templateUrl: './newbooks.component.html',
  styleUrls: ['./newbooks.component.css']
})
export class NewbooksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
