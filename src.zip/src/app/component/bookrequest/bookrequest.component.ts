import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookrequest',
  templateUrl: './bookrequest.component.html',
  styleUrls: ['./bookrequest.component.css']
})
export class BookrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
