import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stationary',
  templateUrl: './stationary.component.html',
  styleUrls: ['./stationary.component.css']
})
export class StationaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
