import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewbooksComponent } from './component/newbooks/newbooks.component';
import { StationaryComponent } from './component/stationary/stationary.component';
import { BookrequestComponent } from './component/bookrequest/bookrequest.component';
import { HeaderComponent } from './component/header/header.component';
import { CartComponent } from './component/cart/cart.component';
import { HomeComponent } from './component/home/home.component';
import { FooterComponent } from './component/footer/footer.component';

const routes: Routes = [ 
  { path:'', redirectTo: 'home', pathMatch:'full'},
  { path:'newbooks', component: NewbooksComponent},
  { path:'bookrequest', component: BookrequestComponent},
  { path:'home', component: HomeComponent},
  { path:'stationary', component: StationaryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
